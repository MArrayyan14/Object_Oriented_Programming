#ifndef _DynamicArray_h
#define _DynamicArray_h

class DynamicArray{
    private:
    int* arr;
    int size;

    public:
    DynamicArray(int s);
    ~DynamicArray();

    void set(int index, int value);

    int get(int index);

   /* DynamicArray(const DynamicArray& other);*/
 DynamicArray(const DynamicArray& other); 

    void print();

};
#endif