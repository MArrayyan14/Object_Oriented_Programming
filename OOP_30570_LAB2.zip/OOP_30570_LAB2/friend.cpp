#include "friend.h"
#include <iostream>




using namespace std;

fraction :: fraction(int n , int d): numerator(n), denominator(d){};

fraction addFractions(const fraction&a, const fraction&b ){
    int n = a.numerator + b.numerator;
    int d = a.denominator + b.denominator;
    return fraction(n, d); 
}

void fraction:: display(){
        cout << numerator;
        cout << " / " ;
        cout << denominator; 
        cout  << endl;
    }
fraction multiplyFractions(const fraction&c, const fraction&e){
    int n = c.numerator * e.numerator;
    int d = c.denominator * e.denominator;
    return fraction(n, d);

}

