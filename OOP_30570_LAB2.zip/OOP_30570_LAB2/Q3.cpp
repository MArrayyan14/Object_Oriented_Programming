#include "friend.h"
#include <iostream>




using namespace std;

int main(){
    fraction fraction1(3, 5);
    fraction fraction2(2, 5);
    cout << "fraction 1: ";
    fraction1.display();
    cout << "fraction 2: ";
    fraction2.display();

    cout << "sum of fractions: ";
    addFractions(fraction1, fraction2);





    return 0;
}