#include "DynamicArray.h"
#include <iostream>
using namespace std;



int main(){
    DynamicArray array1(5);
    array1.set(2, 9);
    array1.set(3, 4);
    array1.set(4, 5);

    cout << "output with Deep Copy: " << endl;
    cout << "value at index 3: " << array1.get(3) << endl;
    
    
    cout << "Original Array: " ;
    array1.print();
    
    DynamicArray array2(array1);

    cout << "copied array with a copy constructor: ";
    array2.print(); 

    array1.set(2,7);

    cout <<"array 1 after modification: ";
    array1.print();
    cout << "array 2: ";
    array2.print();



    return 0;
}