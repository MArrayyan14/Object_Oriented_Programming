#ifndef _friend_h
#define _friend_h


class fraction{
    private: 
    int numerator;
    int denominator;

    public:
   
   fraction(int n, int d);
    friend fraction addFractions(const fraction& a , const fraction& b);
    friend fraction multiplyFractions(const fraction& c, const fraction& e); 

    void display();


};
#endif