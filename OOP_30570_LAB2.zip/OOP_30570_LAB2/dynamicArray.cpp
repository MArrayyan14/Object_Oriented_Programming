#include "DynamicArray.h"
#include <iostream>
using namespace std;



DynamicArray :: DynamicArray(int s) : size(s){
    arr = new int{size};
        for(int i=0; i<size; i++){
            arr[i] = 0;
        }

}
DynamicArray :: ~DynamicArray(){
    delete[] arr;
}

void DynamicArray :: set(int index, int value){
    if(index > 0 && index <size){
         arr[index] = value;
    }
    else{
        cout << "index out of range";
    }
} 

int DynamicArray :: get(int index){
    if(index > 0 && index <size){
        return arr[index];
}    else{
        cout << "index out of range";
        return 0;
    }

}
/*shallow copy
DynamicArray :: DynamicArray(const DynamicArray& other) : arr(other.arr), size(other.size){}*/

DynamicArray :: DynamicArray(const DynamicArray& other)  {
    size = other.size;
    arr = new int[size];
    for(int i=0; i<size; i++){
        arr[i] = other.arr[i];
    }
}

void DynamicArray :: print(){
    for(int i=0; i<size; i++){
        cout << arr[i]<< " ";
    }
    cout << endl;
}